<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StudentController extends Controller
{

    public function index()
    {
        $student = Student::paginate(10);
        return response()->json(['status' => true, 'message' => 'Record Found', 'data' => $student]);
    }


    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $request->validate([
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'max:255', 'unique:students'],
            'subject' => ['required', 'string', 'max:255'],
            'prority' => ['required', 'string', 'max:255'],
        ]);
        Student::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'subject' => $request->subject,
            'prority' => $request->prority,
        ]);
        return response()->json(['status' => true, 'message' => 'Student Add Successfully'], 200);
    }

    public function show($id)
    {
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        $student = Student::find($id);
        if ($student) {
            $student->delete();
            return response()->json(['status' => true, 'message' => 'Student Delete Successfully'], 200);
        }
    }
}
