composer install

php artisan migrate:fresh --seed

php artisan passport:install

php artisan serve

admin@gmail.com
password